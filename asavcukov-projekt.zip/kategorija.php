<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>kategorija</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <a href='index.php' class='back'>
    <img src='images/arrow.svg'/>
    BACK
    </a>
    <?php
    include 'connect.php';
    $kategorija = $_GET['kategorija'];
    $query = "SELECT * FROM vijesti WHERE kategorija='$kategorija'";
    $result = mysqli_query($dbc, $query);
    echo "<section class='grid-container'>";
    if($result){
        while($row = mysqli_fetch_array($result)){
            echo "
                <article>
                        <a href='clanak.php?id=".$row['id']."&kat=".$kategorija."'>
                        <p class='capital'>".$row['kategorija']."</p>
                        <h3 class='title'>".$row['naslov']."</h3>
                        <img class='slika' src='images/".$row['slika']."'/>
                        <h5 class='sazetak'>".$row['sazetak']."</h5>
                        </a>
                </article>
                ";
        }
    }
    echo "</section>";
    
    ?>
    
</body>
</html>