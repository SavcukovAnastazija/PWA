<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>unos vijesti</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
    
</head>
<body>
    <header>
        <a href="index.php"><h1>El Confidencial</h1>
        <p>EL DIARIO DE LOS LECTORES INFLUYENTES</p></a>
    </header>
        <nav>
            <ul>
                <a href="index.php"><li>HOME</li></a>
                <a href="kategorija.php?kategorija=arts"><li>ARTS&CULTURE</li></a>
                <a href="kategorija.php?kategorija=news"><li>NEWS</li></a>
                <a href="administrator.php"><li>ADMINISTRACIJA</li></a>
                <a href="registracija.php"><li>REGISTRACIJA</li></a>
                <a href="#"><li>UNOS</li></a>
            </ul>
        </nav>
        <hr/>
    <main>
        <section class="grid-container">
            <form action="skripta.php" enctype="multipart/form-data" method="POST">
                Naslov:<br/>
                <input type="text" autofocus id="title" name="naslov"/><br/>
                <span id="porukaTitle"></span><br/>
                Sažetak:<br/>
                <textarea rows="5" cols="30" id="about" name="sazetak"></textarea><br/>
                <span id="porukaAbout"></span><br/>
                Tekst vijesti:<br/>
                <textarea rows="7" cols="30" id="content" name="tekst"></textarea><br/>
                <span id="porukaContent"></span><br/>
                Izaberite kategoriju:
                <select name="kategorija" id="kategorija">
                    <option value="news">News</option>
                    <option value="arts">Arts&Culture</option>
                    <option value="entertainment">Entertainment</option>
                    <option value="sports">Sports</option>
                  </select><br/>
                  <span id="porukaKategorija"></span><br/>
                Izaberite sliku:<br/>
                <input type="file" id="slika" name="slika" accept="image/jpg, image/jpeg, image/gif, image/png"/><br/>
                <span id="porukaSlika"></span><br/>
                Arhiviraj vijest?<br/>
                <input type="checkbox" name="da" id="da" value="da"/>Da<br/>
                <button type="reset">Poništi</button>
                <button type="submit" id="poslano" name="poslano">Pošalji</button><br/>
            </form>
        </section>
    </main>
    <footer>
        <ul>
            <li>TITANIA COMPANIA EDITORIAL</li>
            <li>Espana</li>
            <li>Condiciones</li>
            <li>Politica de Privacidad</li>
            <li>Politica de Cookies</li>
            <li>Transparencia</li>
        </ul>
    </footer>

    <script type="text/javascript">
        document.getElementById("poslano").onclick = function(event){ 
            var slanjeForme = true;
            var poljeTitle = document.getElementById("title"); 
            var title = document.getElementById("title").value;

            if (title.length < 5 || title.length > 30) {
                slanjeForme = false;
                poljeTitle.style.border="1px dashed red"; 
                document.getElementById("porukaTitle").innerHTML="Naslov vjesti mora imati između 5 i 30 znakova!<br>"; 
            } else {
                poljeTitle.style.border="1px solid green";
                document.getElementById("porukaTitle").innerHTML=""; 
            }

            var poljeAbout = document.getElementById("about"); 
            var about = document.getElementById("about").value; 
            if (about.length < 10 || about.length > 100) {
                slanjeForme = false;
                poljeAbout.style.border="1px dashed red"; 
                document.getElementById("porukaAbout").innerHTML="Kratki sadržaj mora imati između 10 i 100 znakova!<br>"; 
            } else {
                poljeAbout.style.border="1px solid green";
                document.getElementById("porukaAbout").innerHTML=""; 
            }

            var poljeContent = document.getElementById("content"); 
            var content = document.getElementById("content").value; 
            if (content.length == 0) {
                slanjeForme = false;
                poljeContent.style.border="1px dashed red"; 
                document.getElementById("porukaContent").innerHTML="Sadržaj mora biti unesen!<br>";
            } else {
                poljeContent.style.border="1px solid green";
                document.getElementById("porukaContent").innerHTML=""; 
            }

            var poljeSlika = document.getElementById("slika"); 
            var photo = document.getElementById("slika").value; 
            if (photo.length == 0) {
                slanjeForme = false;
                poljeSlika.style.border="1px dashed red"; 
                document.getElementById("porukaSlika").innerHTML="Slika mora biti unesena!<br>";
            } else {
                poljeSlika.style.border="1px solid green";
                document.getElementById("porukaSlika").innerHTML=""; 
            }

            var poljeKategorija = document.getElementById("kategorija"); 
            if(document.getElementById("kategorija").selectedIndex == 0) {
                slanjeForme = false; 
                poljeKategorija.style.border="1px dashed red";
                document.getElementById("porukaKategorija").innerHTML="Kategorija mora biti odabrana!<br>";
            } else {
                poljeKategorija.style.border="1px solid green"; 
                document.getElementById("porukaKategorija").innerHTML="";
            }

            if (slanjeForme != true) { 
                event.preventDefault();
            }
        };
</script>
    
</body>
</html>