<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registracija</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <header>
        <a href="index.php"><h1>El Confidencial</h1>
        <p>EL DIARIO DE LOS LECTORES INFLUYENTES</p></a>
    </header>
    <nav>
        <ul>
        <a href="index.php"><li>HOME</li></a>
        <a href="kategorija.php?kategorija=arts"><li>ARTS&CULTURE</li></a>
        <a href="kategorija.php?kategorija=news"><li>NEWS</li></a>
        <a href="administrator.php"><li>ADMINISTRACIJA</li></a>
        <a href="#"><li>REGISTRACIJA</li></a>
        <a href="unos.php"><li>UNOS</li></a>
        </ul>
    </nav>

    <?php
    session_start();
    if(isset($_SESSION['username'])){
        echo "Već ste ulogirani kao ".$_SESSION['username'];
    }
    else{
        echo "
        <main>
        <form action='registracija.php' method='POST' class='forma-admin'>
        <span id='porukaIme' class='bojaPoruke'></span><br/>
        <label for='ime'>Ime: </label><br/>
        <input type='text' name='ime' id='ime'/><br/>
        <span id='porukaPrezime' class='bojaPoruke'></span><br/>
        <label for='prezime'>Prezime: </label><br/>
        <input type='text' name='prezime' id='prezime'/><br/>
        <span id='porukaUsername' class='bojaPoruke'></span><br/>
        <label for='username'>Korisničko ime:</label><br>
        <span class='bojaPoruke'></span><br/>
        <input type='text' name='username' id='username'/><br/>
        <span id='porukaPass' class='bojaPoruke'></span><br/>
        <label for='pass'>Lozinka: </label><br/>
        <input type='password' name='pass' id='pass'/><br/>
        <span id='porukaPassRep' class='bojaPoruke'></span><br/>
        <label for='passRep'>Ponovite lozinku: </label><br/>
        <input type='password' name='passRep' id='passRep'/><br/>
        <button type='submit' value='Prijava' name='poslano' id='poslano'>Prijava</button><br/>
        </form>
        <main>
        ";
    }
?>

    <script type="text/javascript"> 
    document.getElementById("poslano").onclick = function(event){

        var slanjeForme = true;
        var poljeIme = document.getElementById("ime"); 
        var ime = document.getElementById("ime").value; 
        if (ime.length < 1) {
            slanjeForme = false;
            poljeIme.style.border="1px dashed red"; 
            document.getElementById("porukaIme").innerHTML="Unesite ime!"
        } else {
            poljeIme.style.border="1px solid green";
            document.getElementById("porukaIme").innerHTML=""; 
        }

        var poljePrezime = document.getElementById("prezime"); 
        var prezime = document.getElementById("prezime").value; 
        if (prezime.length < 1) {
            slanjeForme = false;
            poljePrezime.style.border="1px dashed red";
            document.getElementById("porukaPrezime").innerHTML="Unesite prezime!"; 
        } 
        else {
            poljePrezime.style.border="1px solid green";
            document.getElementById("porukaPrezime").innerHTML=""; 
        }

        var poljeUsername = document.getElementById("username"); 
        var username = document.getElementById("username").value; 
        if (username.length < 1) {
        slanjeForme = false; poljeUsername.style.border="1px dashed red";
        document.getElementById("porukaUsername").innerHTML="Unesite korisničko ime!";
        } else {
        poljeUsername.style.border="1px solid green"; 
        document.getElementById("porukaUsername").innerHTML="";
        }

        var poljePass = document.getElementById("pass");
        var pass = document.getElementById("pass").value;
        var poljePassRep = document.getElementById("passRep");
        var passRep = document.getElementById("passRep").value;
        if (pass.length == 0 || passRep.length == 0 || pass != passRep) {
            slanjeForme = false;
            poljePass.style.border="1px dashed red"; 
            poljePassRep.style.border="1px dashed red"; 
            document.getElementById("porukaPass").innerHTML="Lozinke nisu iste!";
            document.getElementById("porukaPassRep").innerHTML="Lozinke nisu iste!"; } 
        else {
            poljePass.style.border="1px solid green"; 
            poljePassRep.style.border="1px solid green"; 
            document.getElementById("porukaPass").innerHTML=""; 
            document.getElementById("porukaPassRep").innerHTML="";
        }

        if (slanjeForme != true) { 
            event.preventDefault();
        }
    }
</script>


    <?php

    if(isset($_POST['poslano'])){

        $ime = $_POST['ime'];
        $prezime = $_POST['prezime'];
        $username = $_POST['username'];
        $lozinka = $_POST['pass'];
        $hash = password_hash($lozinka, CRYPT_BLOWFISH); 
        $razina = 0;
        $registriran = false;

        $dbc = mysqli_connect('localhost', 'root', '', 'projekt');
        $upit = "SELECT kime FROM korisnik WHERE kime=?";
        $stmt = mysqli_stmt_init($dbc);
        if(mysqli_stmt_prepare($stmt, $upit)){
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }
        if(mysqli_stmt_num_rows($stmt) > 0){
            echo "Korisničko ime već postoji!";
        }
        else{
            $unos = "INSERT INTO korisnik (ime, prezime, kime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($dbc);
            if(mysqli_stmt_prepare($stmt, $unos)){
                mysqli_stmt_bind_param($stmt, 'ssssi', $ime, $prezime, $username, $hash, $razina);
                mysqli_stmt_execute($stmt);
                $registriran = true;
            }
        }
    
        if($registriran){
            echo "<br/>Korisnik uspješno registriran!<br/>";
        }
        else{
            exit;
        }

    }
?>
    
</body>
</html>