<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>početna</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <?php
    include 'connect.php';
    mysqli_report(MYSQLI_REPORT_ERROR);
    $id=$_GET['id'];
    $query = "SELECT * FROM vijesti WHERE id=$id";
    $result = mysqli_query($dbc, $query);
    $row = mysqli_fetch_array($result);
    echo "
    <a href='".(isset($_GET['kat']) ? "kategorija.php?kategorija=".$_GET['kat'] : "index.php")."' class='back'>
    <img src='images/arrow.svg'/>
    BACK
    </a>
    <header>
        <ol>
            <li>".$row['kategorija']."</li>
        </ol>
    </header>
    <hr/>
    <main> 
        <section class='grid-container'>
            <article>
                <p>".date('d.m.Y H:i:s', strtotime($row['vrijeme']))."</p>
                <h1>".$row['naslov']."</h1>
                <h3>".$row['sazetak']."</h3>
                <img src='images/".$row['slika']."'/>
                <p>".$row['tekst']."</p>
            </article>
        </section>
    </main>
    <footer>
        <ul>
            <li>TITANIA COMPANIA EDITORIAL</li>
            <li>Espana</li>
            <li>Condiciones</li>
            <li>Politica de Privacidad</li>
            <li>Politica de Cookies</li>
            <li>Transparencia</li>
        </ul>
    </footer>
";
?>
</body>
</html>