<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>početna</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <header>
        <a href="#"><h1>El Confidencial</h1>
        <p>EL DIARIO DE LOS LECTORES INFLUYENTES</p></a>
    </header>
        <nav>
            <ul>
                <a href="#"><li>HOME</li></a>
                <a href="kategorija.php?kategorija=arts"><li>ARTS&CULTURE</li></a>
                <a href="kategorija.php?kategorija=news"><li>NEWS</li></a>
                <a href="administrator.php"><li>ADMINISTRACIJA</li></a>
                <a href="registracija.php"><li>REGISTRACIJA</li></a>
                <a href="unos.php"><li>UNOS</li></a>
            </ul>
        </nav>
        <hr/>
    <main>
        <ol>
            <li>NEWS</li>
        </ol>
        <section class="grid-container">
            <?php
            include 'connect.php';
            $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='news' ORDER BY vrijeme DESC LIMIT 3";
            $result = mysqli_query($dbc, $query);
                while ($row = mysqli_fetch_array($result)){
                    echo "
                    <article class='naslovi'>
                    <a href='clanak.php?id=".$row['id']."'>
                    <div class='imgcontainer'>
                    <img src='images/".$row['slika']."'/>
                    </div>
                    <p>".$row['naslov']."</p>
                    </a>
                    </article>
                    ";
                }
            ?>

        </section>
        <ol>
            <li>ARTS&CULTURE</li>
        </ol>
        <section class="grid-container">
            <?php
            $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='arts' ORDER BY vrijeme DESC LIMIT 3";
            $result = mysqli_query($dbc, $query);
                while ($row = mysqli_fetch_array($result)){
                    echo "
                    <article class='naslovi'>
                    <a href='clanak.php?id=".$row['id']."'>
                    <div class='imgcontainer'>
                    <img src='images/".$row['slika']."'/>
                    </div>
                    <p>".$row['naslov']."</p>
                    </a>
                    </article>
                    ";
                }
            ?>

        </section>
    </main>
    <footer>
        <ul>
            <li>TITANIA COMPANIA EDITORIAL</li>
            <li>Espana</li>
            <li>Condiciones</li>
            <li>Politica de Privacidad</li>
            <li>Politica de Cookies</li>
            <li>Transparencia</li>
        </ul>
    </footer>
</body>
</html>