-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 19, 2022 at 12:45 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) NOT NULL,
  `prezime` varchar(32) NOT NULL,
  `kime` varchar(32) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `razina` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `kime`, `lozinka`, `razina`) VALUES
(2, 'Marija', 'Marić', 'mmaric', '$2y$10$Bed13Ss1Y10v/NNQuoZvvevtdg2mVbRpucvJJy7qe6v.KSHAUiAAi', 0),
(3, 'Ana', 'Stazija', 'anastazija', '$2y$10$B1lg6FLhH/DwVYAoxnwZSugxecKi8MmOAALa6WMujf6BzIKomRXCS', 0),
(4, 'Anastazija', 'Savčukov', 'asavcukov', '$2y$10$m7JZI6KSnHv2FgFGipLlheGYj5FdSXeo.VlXS9uQWg8xy2x89RNFe', 1),
(5, 'gost', 'gost', 'gost1', '$2y$10$Rpll3NgjMqTYbbU/zTj9i.Vo6kr0b5sF56gPL8O1HD/Q5iK0MaO0q', 0),
(6, 'Anamarija', 'Marić', 'amaric', '$2y$10$iolo8Hi2fcnkoKsG/3fqe.WzoqWJQYg2eg1zJfO5kTUxlowPO8rIK', 0),
(7, 'Marija', 'Marić', 'mm', '$2y$10$2NZXaPqjD5KZkRn3v44gg.vc0WKE2dvSJeKxh2rBIxuR2lBlwohEO', 0),
(11, 'ema', 'emić', 'eme', '$2y$10$Yrd8VYzJOZaj1gImddiSCeR5sbiC.BVkVjInGHLhRIrldS5.KbmKu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `vrijeme` timestamp NOT NULL DEFAULT current_timestamp(),
  `naslov` varchar(64) NOT NULL,
  `sazetak` text NOT NULL,
  `tekst` text NOT NULL,
  `slika` varchar(64) NOT NULL,
  `kategorija` varchar(64) NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `vrijeme`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(10, '2022-06-16 10:54:20', 'Mondrian', 'To mark the 150th anniversary of the Dutch avant-gardist’s birth, the Fondation Beyeler has organized a retrospective looking at Mondrian’s earliest abstract experiments, in which he painted windmills and seascapes, through his radical reinvention of painting with his Neo-Plastic canvases, which he began in the 1920s.', 'As one of the most important artists of the avant-garde movement, Mondrian shaped the evolution of painting from figuration to abstraction. His early work was influenced not only by late 19th century Dutch landscape painting but also by Symbolism and Cubism. It was only in the early 1920s that he began concentrating on a wholly non-representational pictorial vocabulary consisting solely of rectilinear arrangements of black lines on a white background and the three primary colours blue, red and yellow.\r\n\r\nWhile the collection of the Fondation Beyeler focuses primarily on works from the later phases of Mondrian’s career, the exhibition will look at his development as an artist up to the 1920s and the stylistic genesis of his later work. Separate sections will deal with motifs such as windmills, dunes and seascapes, the farmstead reflected in water and plants in various states of abstraction. “Mondrian” is organised jointly by the Fondation Beyeler and K20, Kunstsammlung Nordrhein-Westfalen, Düsseldorf.', 'flowers1.jpg', 'arts', 0),
(11, '2022-06-16 10:58:01', 'Plastic: Remaking Our World', '26.03.2022 – 04.09.2022 \r\nVitra Design Museum', 'Plastics have shaped our daily lives like no other material: from packaging to footwear, from household goods to furniture, from automobiles to architecture. A symbol of carefree consumerism and revolutionary innovation, plastics have spurred the imagination of designers and architects for decades. Today, the dramatic consequences of the plastic boom have become obvious and plastics have lost their utopian appeal. The exhibition »Plastic: Remaking Our World« at the Vitra Design Museum examines the history and future of this controversial material: from its meteoric rise in the twentieth century to its environmental impact and to cutting-edge solutions for a more sustainable use of plastic. Exhibits include rarities from the dawn of the plastic age and objects of the pop era as well as numerous contemporary designs and projects ranging from efforts to clean up rivers and oceans to smart concepts for waste reduction and recycling through to bioplastics made from algae and mycelium.', 'flowers2.jpg', 'arts', 0),
(15, '2022-06-16 11:14:01', 'Adorable dogs', 'Two shelter dogs got married', 'A couple of days before we had some volunteers who constructed Peanut and Cashew,” she added. “Their very own chapel in their own time, complete with a bubble machine for added fun for the dogs.', 'dogs1.jpg', 'news', 0),
(16, '2022-06-16 11:16:07', 'Sloth is friends with zookeeper', 'A sloth has formed an adorable relationship with its keeper and refuses to get out of bed until they’ve had their morning cuddles—and a zoo tour.', 'Gordon the sloth, from Drusillas Park in Sussex, took a particular liking to Amelia Jones when the pair first met two years ago. The unlikely friends started their companionship, when Gordon began behaving differently around Amelia than he did with all the other keepers.', 'sloth1.jpg', 'news', 0),
(17, '2022-06-16 11:18:31', 'Beautiful wildlife', 'Dave Newman has a full-time job inside an office, but he always tries to make time to go outside to spy on the local animals.', 'The 42-year-old amateur photographer started out around four years ago in his Lincolnshire, England town, and he is completely self-taught. Whether it’s in the wildlife hides, woodlands, local rivers, or simply driving around, Dave can be seen stalking the cute and the curious on his artistic quest.', 'duckling-reflection-by-Dave-Newman-SWNS.jpg', 'news', 0),
(20, '2022-06-16 15:47:58', 'Mondrian Painting', 'Celebrated Dutch artist Piet Mondrian is a pioneer of 20th century abstract art who lived in Paris, London and New York, with his art reflecting his migrations.', 'In 1892, Mondrian moved to Amsterdam to study at the Rijksacademie where he produced his first works as an artist. He often painted scenery around Amsterdam, and became known as a landcape painter.', 'feature_mondrian.jpg', 'arts', 0),
(21, '2022-06-16 15:50:33', 'Nature crafting fashion', 'When it comes to inspiration, nature is an incredible source for fashion.', 'Nature has not only been a ‘passive’ source of inspiration, though: it has been an active participant in fashion, providing the very materials that turn ideas into clothes and accessories with very distinct aesthetic and physical qualities. What is the relationship between fashion, nature and craft? Working with nature’s raw materials, people developed new techniques for creating motifs, fabrics and embellishments to be used in the production of garments and accessories.', 'Comb_in_the_form_of_two_dragonflies.jpeg', 'arts', 0),
(30, '2022-06-19 10:30:19', 'Ratko Petrić', '20.04.2022 - 20.06.2022 / PROVIDUROVA PALAČA', 'Nakon premijernog izdanja retrospektive Ratka Petrića 2021. u Muzeju suvremene umjetnosti u Zagrebu, izložba se predstavlja u novouređenom prostoru Providurove palače u Zadru. Ovo je centralni događaj otvorenja novog kompleksa Dvije palače, koji predstavlja integralnu cjelinu Providurove i Kneževe Palače i rezultat suradnje MSU-a i Umjetničke galerije Narodnog muzeja Zadra.', 'msu.jpg', 'arts', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kime` (`kime`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
