<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Administracija</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <header>
        <a href="index.php"><h1>El Confidencial</h1>
        <p>EL DIARIO DE LOS LECTORES INFLUYENTES</p></a>
    </header>
        <nav>
            <ul>
                <a href="index.php"><li>HOME</li></a>
                <a href="kategorija.php?kategorija=arts"><li>ARTS&CULTURE</li></a>
                <a href="kategorija.php?kategorija=news"><li>NEWS</li></a>
                <a href="#"><li>ADMINISTRACIJA</li></a>
                <a href="registracija.php"><li>REGISTRACIJA</li></a>
                <a href="unos.php"><li>UNOS</li></a>
            </ul>
        </nav>
    <hr/>

    <?php

    include 'connect.php';
    session_start();
    $uspjesnaprijava = false;
    if(isset($_POST['posalji'])){
        $korisnik = $_POST['kime'];
        $lozinka = $_POST['lozinka'];
        
        $stmt = mysqli_stmt_init($dbc);
        $provjera = "SELECT lozinka, razina FROM korisnik WHERE kime=?";
        if(mysqli_stmt_prepare($stmt, $provjera)){
            mysqli_stmt_bind_param($stmt, 's', $korisnik);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            mysqli_stmt_bind_result($stmt, $hlozinka, $razinadb);
            mysqli_stmt_fetch($stmt);
        }
        if(mysqli_stmt_num_rows($stmt) > 0){
            if(password_verify($lozinka, $hlozinka)){
                $_SESSION['username'] = $korisnik;
                $_SESSION['admin'] = $razinadb;
                $uspjesnaprijava = true;
            }
            else
                echo "<p class='obavijest'>Kriva lozinka.</p>";
        }
        else{
            echo "<p class='obavijest'>Nemate korisnički račun? <a href='registracija.php'>Registrirajte se!</a></p>";
        }
    }
    if(isset($_SESSION['username'])) $uspjesnaprijava = true;

    if (!$uspjesnaprijava)
    {
        echo    
        '<section class="grid-container">
        <form action="administrator.php" method="POST" class="forma-admin">
            <h4>Login forma</h4>
            <p>*Logiraj se za pristup administratorskoj tablici</p><br/><br/>
            Unesite korisničko ime:<br/>
            <input type="text" name="kime"/><br/>
            Unesite lozinku:<br/>
            <input type="password" name="lozinka"/><br/>
            <button type="submit" name="posalji" id="posalji">Login</button>
        </form>
        </section>';
    } 
    if(isset($_SESSION['username']) && isset($_SESSION['admin']) && $_SESSION['admin'] != 1)
        echo "<p class='obavijest'>".$_SESSION['username'].", nemate administratorska prava.</p>";

    if(isset($_SESSION['username']) && isset($_SESSION['admin']) && $_SESSION['admin'] == 1){
        echo "<h2>Administratorska forma</h2>";
                        
        if(isset($_POST['delete'])){
            $id=$_POST['id'];
            $brisanje = "DELETE FROM vijesti WHERE id=$id"; 
            $result = mysqli_query($dbc, $brisanje);
            if($result){
                echo "<p class='obavijest'>Uspješno obrisano.</p>";
            }
        }

        if(isset($_POST['update'])){
            $title=$_POST['naslov']; 
            $about=$_POST['sazetak']; 
            $content=$_POST['tekst']; 
            $category=$_POST['kategorija']; 
                if(isset($_POST['arhiva'])){
                    $archive=1;
                }else{
                    $archive=0;
                }
            $id=$_POST['id'];
            $update = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content', kategorija='$category', arhiva='$archive' WHERE id=$id"; 
            $result = mysqli_query($dbc, $update);
            if($result){
                echo "<p class='obavijest'>Uspješno ažurirano.</p>";
            }
        }
        $query = "SELECT * FROM vijesti";
        $result = mysqli_query($dbc, $query); 
        while($row = mysqli_fetch_array($result)){
            echo '
            <section class="grid-container">
            <form enctype="multipart/form-data" class="forma-admin" action="administrator.php" method="POST">
                <label for="naslov">Naslov vjesti:</label><br/>
                <input type="text" name="naslov" value="'.$row['naslov'].'"><br/>
                <label for="about">Kratki sadržaj vijesti (do 50 znakova):</label><br/>
                <textarea name="sazetak" id="sazetak" cols="30" rows="10">'.$row['sazetak'].'</textarea><br/>
                <label for="tekst">Sadržaj vijesti:</label><br/>
                <textarea name="tekst" id="tekst" cols="30" rows="10">'.$row['tekst'].'</textarea><br/>
                <label for="slika">Slika:</label><br/>
                <img src="images/'. $row['slika'] .'"><br/>
                <label for="kategorija">Kategorija vijesti:</label><br/>
                <select name="kategorija" id="kategorija" value="'.$row['kategorija'].'">
                <option value="news" '.($row['kategorija'] == 'news' ? "selected":"").'/>News<br/>
                <option value="arts" '.($row['kategorija'] == 'arts' ? "selected":"").'/>Arts&Culture<br/>
                </select>
                <br/>
            ';
            if($row['arhiva'] == 0) {
                echo '<input type="checkbox" name="arhiva" id="arhiva"/><br/>';
                }
            echo '
            <input type="hidden" name="id" value="'.$row['id'].'">
            <button type="reset" value="Poništi">Poništi</button> 
            <button type="submit" name="update" value="Prihvati">Izmjeni</button>
            <button type="submit" name="delete" value="Izbriši">Izbriši</button><br/><br/>
            </form>
            </section>';
            }
        }
    ?>
</body>
</html>