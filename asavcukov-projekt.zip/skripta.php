<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <title>Skripta</title>
</head>
<body>
<?php

    if (isset($_POST['naslov'])){
    
        include 'connect.php';

        $naslov = $_POST['naslov'];
        $kategorija = $_POST['kategorija'];
        $sazetak = $_POST['sazetak'];
        $tekst = $_POST['tekst'];

        $picture = $_FILES['slika']['name'];
        $target_dir = 'images/'.$picture;
        move_uploaded_file($_FILES["slika"]["tmp_name"], $target_dir);

        if (isset($_POST['arhiva'])){
            $arhiva = 1;
        }
        else $arhiva = 0;

        $stmt = mysqli_stmt_init($dbc);
        $query = "INSERT INTO vijesti (naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES (?, ?, ?, ?, ?, ?)";
        if(mysqli_stmt_prepare($stmt, $query)){
            mysqli_stmt_bind_param($stmt, 'sssssi', $naslov, $sazetak, $tekst, $picture, $kategorija, $arhiva);
            if (mysqli_execute($stmt)){
            echo "
            <main>
            <section>
            <h3>Category: $kategorija</h3>
            <h2>$naslov</h2>
            <p>$sazetak</p>
            <img src='images/$picture'/>
            <p>$tekst</p>
            </section>
            </main>"
            
            ;
            } 
        }
        

    }

?>
    
</body>
</html>
